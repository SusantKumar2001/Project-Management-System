<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  
  <style>
    *{
        margin:0;
        padding:0;
        box-sizing: border-box;
    }
    body{
        background-image:linear-gradient(rgba(0,0,0,0.8),rgba(0,0,0,0.8)),url("iot4.jpg");
        height: 100vh;
        background-size: cover;
        background-position:center;
    }
    #bg{
        height: 8%;
        width:100%;
        background-color: #17252A;
        color:#fff;
    }
    
    .skb{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin:28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
        
    }
    .skb2{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin:28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
    }
    .skb3{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin:28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
    }
    .skb4{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin: 28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
    }
    .skb5{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin: 28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
    }
    .skb6{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin: 28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
    }
    .skb7{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin: 28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
    }
    .skb8{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin: 28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
    }
    .skb9{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin: 28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
    }
    .skb10{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin: 28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
    }
    .skb11{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin: 28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
    }
    .skb12{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin: 28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
    }
    .skb13{
        height:200px;
        width:20%;
        background-color: #116466;
        color:wheat;
        float:left;
        margin: 28px;
        border:3px solid wheat;
        border-radius: 10px;
        box-shadow:0 0 9px green;
    }
    .btn{
        height:1cm;
        width:2cm;
        background-color: wheat;
        border:2px dotted black;
        border-radius: 10px 10px 10px 10px;
        transition:0.6s ease;
        cursor: pointer;
    }
    .s:hover{
        box-shadow: 0 0 9px rgba(0,0,0,1);
    }
    .btn:hover{
        background-color:#fff;
        box-shadow: 0 0 9px rgba(0,0,0,1);
    }
    
  </style>
</head>
<body>
    <div id="bg"> 
        
        <h1>Centurion University</h1>
    </div>
    <div class="skb s">
        <br><br>
        <center>
            <h1>Group 1</h1><br><br>
            <a href="loging1.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>
    <div class="skb2 s">
        <br><br>
        <center>
            <h1>Group 2</h1><br><br>
            <a href="loging2.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>
    <div class="skb3 s">
        <br><br>
        <center>
            <h1>Group 3</h1><br><br>
            <a href="loging3.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>
    <div class="skb4 s">
        <br><br>
        <center>
            <h1>Group 4</h1><br><br>
            <a href="loging4.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>
    <div class="skb5 s">
        <br><br>
        <center>
            <h1>Group 5</h1><br><br>
            <a href="loging5.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>
    <div class="skb6 s">
        <br><br>
        <center>
            <h1>Group 6</h1><br><br>
            <a href="loging6.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>
    <div class="skb7 s">
        <br><br>
        <center>
            <h1>Group 7</h1><br><br>
            <a href="loging7.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>
    <div class="skb8 s">
        <br><br>
        <center>
            <h1>Group 8</h1><br><br>
            <a href="loging8.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>
    <div class="skb9 s">
        <br><br>
        <center>
            <h1>Group 9</h1><br><br>
            <a href="loging9.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>
    <div class="skb10 s">
        <br><br>
        <center>
            <h1>Group 10</h1><br><br>
            <a href="loging10.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>
    <div class="skb11 s">
        <br><br>
        <center>
            <h1>Group 11</h1><br><br>
            <a href="loging11.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>
    <div class="skb12 s">
        <br><br>
        <center>
            <h1>Group 12</h1><br><br>
            <a href="loging12.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>
    <div class="skb13 s">
        <br><br>
        <center>
            <h1>Group 13</h1><br><br>
            <a href="loging13.php"><button class="btn" type="submit">Log in</button></a></center>
    </div>

</body>