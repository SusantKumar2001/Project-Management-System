
<html>
<head>
	
	<title>Login</title>
	<style>
	   *{
       
       box-sizing: border-box;
}
body{
       background-image:url("iot2.jpg");
       height:100vh;
	background-size:cover;
	background-position:center;
}
h1{
       color: #1A77F2;
       text-align: center;
       margin: 30px;
       font-size: 50px;
       letter-spacing: -2px;
       font-family: 'Roboto', sans-serif;
}
.login_form{
       margin: auto;
       background-color: white;
       justify-content: center;
       width: 400px;
       padding: 30px;
       border-radius: 10px;
       box-shadow: 0 0 10px rgba(27, 27, 27, 0.2);
}
input{
       width: 100%;
       margin-top: 10px;
       height: 45px;
       border-radius: 5px;
       padding: 6px;
       font-size: 14px;
       border: 0.1px solid rgba(27, 27, 27, 0.2);
}
button{
       background-color: #1A77F2;
       color: white;
	   width: 100%;
       margin-top: 10px;
       height: 45px;
       border-radius: 5px;
       padding: 6px;
       font-size: 14px;
       border: 0.1px solid rgba(27, 27, 27, 0.2);
}
a,#foter{
       margin-top: 20px;
       text-decoration: none;
       text-align: center;
       font-size: 18px;
       color: #3E76F2;
}
p{
       text-align: center;
       font-size: 18px;
}

	</style>
<body>
	<br><br><br><br>
	
	<div class="login_form">
		<p>Log in to Centurion<p>
		<form action="#" method="post">
			<input type="email" name="email" placeholder="Enter your email">
			<input type="password" name="passwd" placeholder="Enter your password">
			<button type="submit" name="submit">Login</button>
		</form>
		</div>
<?php
session_start();
if(isset($_POST['submit']))
{
       $a = mysql_connect("localhost","root","");
       $b = mysql_select_db("pgms");
       $email = $_POST['email'];
       $pwd = $_POST['passwd'];
       if($email!='' && $pwd!='')
       {
              $query=mysql_query("select * from admin where email='".$email."' and passwd='".$pwd."'") or die(mysql_error());
              $res = mysql_fetch_row($query);
              if ($email != '' && $pwd != '') {
                     $query = mysql_query("select * from admin where email='" . $email . "' and passwd='" . $pwd . "'") or die(mysql_error());
                     $res = mysql_fetch_row($query);
                     if ($res) {
                         $_SESSION['name'] = $email;
                         header('location:new2.php');
                     } else {
                         echo '<script>alert("You entered username or password is incorrect !");</script>';
                     }
                 } else {
                     echo '<script>alert("id and password should not be left blank");</script>';
                 }
                 

       }
} 
?>         
</body>
</html>

