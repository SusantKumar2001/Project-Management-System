<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Registration Page</title>
  <style>
    * {
  box-sizing: border-box;
  font-family: Arial, sans-serif;
}

body {
  background-image:linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url("iot5.jpg");
  height:100vh;
  background-size:cover;
  background-position:center;
  margin: 0;
  padding: 0;
}

.container {
  width: 500px;
  margin: 50px auto;
  padding: 30px;
  border-radius: 10px;
  background-color: #fff;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

form {
  display: flex;
  flex-direction: column;
}

h1 {
  text-align: center;
  margin-bottom: 30px;
}

.form-group {
  display: flex;
  flex-direction: column;
  margin-bottom: 20px;
}

label {
  font-weight: bold;
  margin-bottom: 5px;
}

input[type="text"], input[type="email"], input[type="password"] {
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

button[type="submit"] {
  margin-top: 20px;
  padding: 10px;
  border: none;
  border-radius: 5px;
  background-color: #4CAF50;
  color: #fff;
  cursor: pointer;
  font-size: 16px;
  font-weight: bold;
  text-transform: uppercase;
}

button[type="submit"]:hover {
  background-color: #3e8e41;
}
#coding{
  height:30px;
}
#hardware{
  height:30px;
}
#software{
  height:30px;
}
#others{
  height:30px;
}

  </style>
</head>
<body>
  <div class="container">
    <form action="connectg6.php" method="post">
      <h1>Enter your data</h1>
      <div class="form-group">
        <label for="coding">Coding(in %):</label>
        <input type="number" id="coding" name="c1" placeholder="Enter your coding %">
      </div>
      <div class="form-group">
        <label for="hardware">Hardware(in %):</label>
        <input type="number" id="hardware" name="h1" placeholder="Enter your hardware %">
      </div>
      <div class="form-group">
        <label for="software">Software(in %):</label>
        <input type="number" id="software" name="s1" placeholder="Enter your software %">
      </div>
      <div class="form-group">
        <label for="other">Others(in %):</label>
        <input type="number" id="others" name="o1" placeholder="Other instruments">
      </div>
      <button type="submit" name="submit">Enter</button>
    </form>
  </div>
<?php
