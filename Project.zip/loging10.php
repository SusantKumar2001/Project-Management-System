<!DOCTYPE html>
<html lang="en" >
<head>
  <title>Login Page with Background Image Example</title>
  
  <style>
#bg {
  background-image:linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.6)),url("iot3.jpg");
  position: fixed;
  width: 100%;
  height: 100%;
  background-size: cover;
}

body {
  font-family: 'Poppins', sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  overflow: hidden;
  margin:0;
  padding: 0;
}

form {
  width: 350px;
  position: relative;
}

form .form-field {
  display: flex;
  align-items: center;
  margin-bottom: 1rem;
  position: relative;

}
form input {
  width: 100%;
  outline: none;
  background-color: #fff;
  border-radius: 4px;
  border: none;
  padding: 0.9rem 0.7rem;
  font-size: 17px;
  color: black;
  text-indent: 40px;
}
form .btn {
  text-decoration:none;
	color:cyan;
	position:absolute;
  background: none;
  left:35%;
	border:1px solid #fff;
  transition:0.7s ease;
  height:1cm;
  width:3cm;
}
button:hover{
  background-color: yellow;
  color:black
}

  </style>

</head>
<body>

<div id="bg"></div>
<form action="#" method="post">
    <h1 style="color:#fff">Login to Project Group</h1>
  <div class="form-field">
    <input type="text" placeholder="Email" name="s1"/>
  </div>
  
  <div class="form-field">
    <input type="password" placeholder="Password"  name="s2"/>                         
  </div><br>
  
  <div class="form-field">
    <button class="btn" type="submit" name="s3">Log in</button>
  </div>

</form>
<?php
session_start();
if(isset($_POST['s3']))
{
       $a = mysql_connect("localhost","root","");
       $b = mysql_select_db("pgms");
       $email = $_POST['s1'];
       $pwd = $_POST['s2'];
       if($email!='' && $pwd!='')
       {
              $query=mysql_query("select * from group10 where email='".$email."' and passwd='".$pwd."'") or die(mysql_error());
              $res = mysql_fetch_row($query);
              if ($email != '' && $pwd != '') {
                     $query = mysql_query("select * from group10 where email='" . $email . "' and passwd='" . $pwd . "'") or die(mysql_error());
                     $res = mysql_fetch_row($query);
                     if ($res) {
                         $_SESSION['name'] = $email;
                         header('location:resultg10.php');
                     } else {
                         echo '<script>alert("You entered username or password is incorrect !");</script>';
                     }
                 } else {
                     echo '<script>alert("id and password should not be left blank");</script>';
                 }
                 

       }
} 
?>         


  
</body>
</html>