<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<style>
    *{
        margin:0;
        padding:0;
    }
    body{
        background-color: #1F2833;
    }
    #s1{
        height:50px;
        width:100%;
        background-color: #fff;
        color: black;
        font-family:Times New Roman;
    }
    #s2{
        height:50px;
        width:100%;
        background-color:#1978A5;
        color:black;
        font-family:Times New Roman;
    }
    
	ol li{
	     
         margin:20px;
         font-size: 0.7cm;
	}
    #s3{
        height:100%;
        width:30%;
        float:left;
        font-family:Open sans;
        color:#fff;
        margin-left:30px;
    }
    #s4{
        height:100%;
        width:800px;
        float:right;
        button: 100px;
        font-family:Open Sans;
        color:#fff;
        margin-right:20px;
    }
    th a{
        text-decoration:none;
        border:1px solid #fff;
        color:#fff;
        transition:0.5s ease;
        cursor:pointer;
        color:black;
        background-color:cyan;
    }
    th a:hover{
        background-color:green;
    }
</style>
<body>
    <div id="s1">
        <h2>Centurion University</h2>

    </div>   
    <div id="s2">
        <center><h2>Project: Smart Street Light</h2></center>
        
    </div> 
    <div id="s3">
        <br><h2><u>Group Students:-</u></h2>
        <ol type="1">
            <li>Susanta Kumar Baral</li>
            <li>Sambit Khilar</li>
            <li>Deepak Mall</li>
            <li>Sambit Subhankar Parida</li>
            <li>Sunil Kumar Sahoo</li>

        </ol>
    </div >
    <div id="s4"><center>
        <br><h2><u>Status:-</u></h2><br>
        <table width=800 height=100 border=5 cellpadding=10 cellspacing=10 >
            <thead>
            <tr bgcolor="orange">
                <th>Coding(%)</th>
                <th>Hardware(%)</th>
                <th>Software(%)</th>
                <th>Others(%)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php

            $connection = new mysqli('localhost','root','','pgms');
            if($connection->connect_error){
                die("Connection failed: ".$connection->connect_error);
            }

            $sql = "SELECT * FROM group9s ORDER BY id DESC LIMIT 1";
            $result = $connection->query($sql);

            if(!$result){
                die("Invalid query: ".$connection->error);
            }

            while($row = $result->fetch_assoc()){
              echo "<tr>
                  <td>" . $row["coding"] . "</td>
                  <td>" . $row["hardware"] . "</td>
                  <td>" . $row["software"] . "</td>
                  <td>" . $row["others"] . "</td>
                  <th><a href='entryg9.php'>Update status</a></th>
                  
            </tr>";

            }
            ?>
            
        </tbody>
        </table></center>
    </div>
</body>
</html>