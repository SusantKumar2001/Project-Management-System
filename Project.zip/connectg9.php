<?php
    $coding = $_POST['c1'];
    $hardware = $_POST['h1'];
    $software = $_POST['s1'];
    $others = $_POST['o1'];

    $conn = new mysqli('localhost','root','','pgms');
    if($conn->connect_error){
        die('connection Failed : '.$conn->connect_error);
    }else{
        if($coding<=100 && $hardware<=100 && $software<=100 && $others<=100){
            $stmt = $conn->prepare("insert into group9s(coding,hardware,software,others)values(? ,? ,? ,?)");
            $stmt->bind_param("iiii",$coding,$hardware,$software,$others);
            $stmt->execute();
            echo '<script>alert("Data entered successfully...");</script>';
            header('location:resultg9.php');
        }else{
            echo '<h1>'."Invalid input".'</h1>';
        
        }
        
        
    }
    
?>