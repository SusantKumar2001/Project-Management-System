<html>
   <head>
      <title>Index page</title>
	  <style>
	  *{
	     margin:0;
		 padding:0;
	   }
	   body{
	     background-image:linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.7)),url("iot.jpg");
		 height:100vh;
		 background-size:cover;
		 background-position:center;
	   }
	   
	   ul{
	     float:right;
	     list-style-type:none;
		 margin-top:20px;
	   }
	   ul li{
	     display:inline-block;
	   }
	   ul li a{
	     text-decoration:none;
		 color:cyan;
		 padding:5px 30px;
		 border:1px solid #fff;
         transition:0.7s ease;	
		 margin:5px;
		 border-radius:7px;	 
	  }
	  ul li a:hover{
	     background-color:yellow;
		 color:black;
	  }
	  ul li.s2 a{
	     background-color:yellow;
		 color:black;
	    } 
	  .s1{
	     max-width:1200px;
		 margin:auto;
	  }
	  .t1{
	     position:absolute;
		 top:50%;
		 left:50%;
		 transform:translate(-50%,-50%);
		 
		 
	  }
	  .t1 h1{
	     color:#fff;
		 font-size:60px;
	  }
	  .b1{
	     position:absolute;
		 top:65%;
		 left:50%;
		 transform:translate(-50%,-50%); 
	  }
	  .b2{
	     border:1px solid #fff;
		 padding:10px 30px;
		 color:black;
		 text-decoration:none;
		 transition:0.7s ease;
		 background-color:#fff;
		 border:2px solid black;
		 border-radius:10px;
	  }
	  .b2:hover{
	     background-color:yellow;
		 color:black;
	  }
	 
	  </style>
   </head>
   <body>
	

        <header>
		<div class="s1">
			
		   <ul>
		      <li class="s2"><a href=" ">Home</a></li>
			  <li><a href="https://cutm.ac.in/about-us/#:~:text=The%20Centurion%20University%20of%20Technology,%2C%20Engineering%2C%20Management%20and%20Agriculture. ">About</a></li>
			  <li><a href="https://courseware.cutm.ac.in/categories-courses/core-courses/">Cources</a></li>
			  <li><a href="https://cutm.ac.in/contact/">Contact</a></li>
			  <li><a href="new1.php">Project</a></li>
		   </ul>
		</div>
		<div class="t1">
			
		       <h1>Centurion University</h1>
		</div>
		<div class="b1">
		      <a href="admin.php" class="b2">LOG IN</a>
			  
		</div>
		</header>
   </body>
</html>